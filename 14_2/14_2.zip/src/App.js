import React from 'react';
import TextArea from "./TextArea";
class App extends React.Component {

  render() {
    return (
      <div>
        <TextArea />
      </div>
    );
  }
}

export default App;
