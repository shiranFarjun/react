import React from 'react';

const Box = (props) => {

  return <div className={props.className}></div>
};

export default Box;

