import React from 'react';
import Box from './Box';

class App extends React.Component {
  render() {
    return (
      <div className="continer">
        <Box />
      </div>
    );
  }
}

export default App;
