import React from 'react';

class Home extends React.Component {
    render() {
        return (
            <div style={{ textAlign: 'center' }}>
                <h2>This is my landing page</h2>
            </div>
        );
    };
};

export default Home;