import React from 'react';
import AutoFocusTextInput from "./AutoFocusTextInput";
import './App.css';

class App extends React.Component {

  render() {
    return (
      <div>
        <AutoFocusTextInput />
      </div>
    );
  }
}

export default App;
